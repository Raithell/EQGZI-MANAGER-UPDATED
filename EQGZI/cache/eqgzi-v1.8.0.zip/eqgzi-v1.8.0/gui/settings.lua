
settings = {
	folder = "C:\\src\\demoncia\\zone\\hollows\\out\\hollows.eqg",
	viewer = {
		width = 600,
		height = 400,
	}
}
